package com.example.chalengeroom2_lutfi

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

//--ONCLICK--
//1.,object : SiswaAdapter.OnAdapterListener{
//            override fun onClick(tbsis: tbsiswa) {
//                 startActivity(Intent(applicationContext,EditActivity::class.java)
//                .putExtra("intent_nis",tbsis.nis)
//              )
//            }
//        })

//Toast.makeText(applicationContext, tbsis.nis, Toast.LENGTH_LONG).show()
//intentEdit(tbsis.nis,Constant.TYPE_READ)
//}
//})


class MainActivity : AppCompatActivity() {

    lateinit var siswaAdapter: BukuAdapter
    val db by lazy { dbperpustakaan(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        halEdit()
        setupRecyclerView()
    }

    override fun onStart() {
        super.onStart()
        CoroutineScope(Dispatchers.IO).launch {
            val siswa = db.tbBukuDao().tampilsemua()
            Log.d("MainActivity", "dbResponse:$siswa")
            withContext(Dispatchers.Main) {
                siswaAdapter.setData(siswa)
            }
        }
    }

    private fun halEdit() {
        btnInput.setOnClickListener {
            intentEdit(0, Constant.TYPE_CREATE)
        }
    }

    fun intentEdit(tbsisnis: Int, intentType: Int) {
        startActivity(
            Intent(applicationContext, EditActivity::class.java)
                .putExtra("intent_nis", tbsisnis)
                .putExtra("intent_type", intentType)
        )
    }

    fun setupRecyclerView() {
        siswaAdapter = SiswaAdapter(arrayListOf(), object : SiswaAdapter.onAdapterListener {
            override fun onClick(tbsis: tbsiswa) {
                intentEdit(tbsis.nis, Constant.TYPE_READ)
            }

            override fun onUpdate(tbsis: tbsiswa) {
                intentEdit(tbsis.nis, Constant.TYPE_UPDATE)
            }
        })

        //idRecyclerView
        listdatasiswa.apply {
            layoutManager = LinearLayoutManager(applicationContext)
            adapter = siswaAdapter
        }
    }


}
