package com.example.chalengeroom2_lutfi

import androidx.room.*

@Dao
interface tbsiswaDao {
    @Insert
    suspend fun addtbsiswa (tbsis: )

    @Update
    suspend fun updatetbsiswa (tbsis: tbsiswa)

    @Delete
    suspend fun deltbsiswa (tbsis: tbsiswa)

    @Query("SELECT * FROM tbsiswa")
    suspend fun tampilsemua() : List<tbsiswa>

    @Query("SELECT * FROM tbsiswa WHERE nis=:siswa_nis")
    suspend fun tampilsemua (siswa_nis: Int) : List<tbsiswa>

}